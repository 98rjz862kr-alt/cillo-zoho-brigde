# Deploiement simple du Cillo Zoho Bridge

## Objectif

Donner une adresse publique HTTPS au bridge pour que Zoho Sites EU puisse afficher les pages validees.

Adresse locale actuelle de test :

```text
http://localhost:3000
```

Adresse attendue apres hebergement :

```text
https://cillo-zoho-bridge.onrender.com
```

Le nom exact sera donne par l'hebergeur.

## Option recommandee

Utiliser Render, avec la region Frankfurt.

Pourquoi :
- l'application Node.js peut y tourner directement ;
- Render fournit une adresse publique HTTPS ;
- la region Frankfurt est adaptee pour un usage europeen ;
- le fichier `render.yaml` est deja prepare dans ce paquet.

## Ce qu'il faut preparer

1. Un compte Render.
2. Un depot GitHub, GitLab ou Bitbucket contenant ce dossier.
3. Un mot de passe admin definitif.
4. Optionnel : une cle OpenAI si la generation automatique de brouillons doit etre activee.

## Variables a renseigner chez l'hebergeur

Obligatoire :

```text
ADMIN_PASSWORD=un-mot-de-passe-long-et-secret
```

Optionnel :

```text
OPENAI_API_KEY=sk-...
OPENAI_MODEL=gpt-5.5
```

Ne pas mettre le mot de passe definitif dans le fichier `.env` du paquet public.

## Verification apres hebergement

Quand l'hebergeur donne l'adresse publique, verifier :

```text
https://ADRESSE-PUBLIQUE/admin
```

Puis verifier la specification API :

```text
https://ADRESSE-PUBLIQUE/openapi.yaml
```

La specification doit exposer seulement :

- `list_site_pages`
- `create_page_draft`
- `update_page_draft`
- `submit_page_for_review`
- `publish_approved_page`

## Integration Zoho Sites EU

Quand une page est publiee dans le bridge, Zoho peut l'afficher avec un iframe :

```html
<iframe
  src="https://ADRESSE-PUBLIQUE/site/main/accueil"
  width="100%"
  height="1200"
  style="border:0;width:100%;min-height:1200px;"
  loading="lazy">
</iframe>
```

Remplacer `ADRESSE-PUBLIQUE` par l'adresse donnee par l'hebergeur.

## Regle de securite

Ne publier aucune page tant que :
- le bridge n'est pas teste en HTTPS ;
- le mot de passe admin definitif n'est pas pose ;
- la page n'a pas ete approuvee humainement ;
- l'utilisateur n'a pas donne une validation explicite.
