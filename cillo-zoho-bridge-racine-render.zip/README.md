# Cillo Zoho Bridge

Cillo Zoho Bridge is a workaround for Zoho Sites when Zoho does not provide the tools needed for an AI agent to create pages, place sections, and publish after validation.

Instead of making the GPT agent click inside Zoho Sites, the agent creates pages in this external mini-CMS. You validate the page, then the bridge publishes it. Zoho Sites displays the published content through an iframe or HTML embed.

## Architecture

```text
GPT Agent / ChatGPT Action
  -> Cillo Zoho Bridge API
  -> draft pages
  -> human review
  -> approved
  -> published endpoint
  -> Zoho Sites iframe/embed
```

## Main workflow

1. The agent creates a page draft.
2. You review the draft in `/admin`.
3. You approve the page.
4. You publish the approved page.
5. Zoho Sites displays `/site/{siteSlug}/{pageSlug}` in an iframe.

## Local setup

```bash
cp .env.example .env
npm run dev
```

Open:

```text
http://localhost:3000/admin
```

Default password comes from `ADMIN_PASSWORD` in `.env`.

The bridge is self-contained for local testing and does not require npm dependencies for the core draft/review/publish workflow.

## Simple online deployment

For a non-technical deployment checklist, see `DEPLOIEMENT-SIMPLE.md`.

This package includes a `render.yaml` file prepared for Render with the Frankfurt region.

## Zoho iframe snippet

Paste this in a Zoho Sites code snippet / embed block:

```html
<iframe
  src="https://YOUR-BRIDGE-DOMAIN.com/site/main/accueil"
  width="100%"
  height="1200"
  style="border:0;width:100%;min-height:1200px;"
  loading="lazy">
</iframe>
```

## GPT / Agent integration

Use `docs/openapi.yaml` as a ChatGPT Action / tool schema, or call the API from your own OpenAI Responses API backend using function calling.

Recommended tools:

- `list_site_pages`
- `create_page_draft`
- `update_page_draft`
- `submit_page_for_review`
- `publish_approved_page`

Approval is intentionally kept in the human admin screen and is not exposed as an agent tool.

## Safety rule

Publishing is blocked unless the page status is `approved`.

```text
draft -> review -> approved -> published
```

The agent can generate and edit drafts. A human should approve before publication.

## Production notes

For production, replace the JSON file storage with PostgreSQL/Supabase/Neon, add real authentication, set CORS rules, add audit logs, and protect the admin routes.
